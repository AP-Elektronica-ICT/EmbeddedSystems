/*******************************************************************************
* Company: Microsemi Corporation
*
* File: main.c
* File history:
*     Revision: Initial version   Date: JUne 01, 2010
*
* Description:
*             This application print the string on OLED display based on user
*             selection.The following options are given:
*
*             1 - Plain Text Display
*             2 - Vertical Scrolling
*             3 - Horizontal Scrolling
*             4 - Sine Wave
*
* Author: Pavan Marisetti
*         pavan.marisetti@microsemi.com
*         Corporate Applications Engineering
********************************************************************************/

#include <stdio.h>
#include <string.h>

#include "mss_watchdog.h"
#include "oled.h"
#include "mss_uart.h"

#define FIRST_CHARACTER 0

/* Function to read the input character */
char readchar (void)
{
    uint8_t rx_size = 0;
    unsigned char rx_char;
    do
    {
        rx_size = MSS_UART_get_rx( &g_mss_uart0, &rx_char, sizeof(rx_char) );
    }while ( rx_size == 0);

    return(rx_char);
}

/* Function for delay */
void delay ( volatile uint32_t n)
{
    while(n!=0)
    {
        n--;
    }
}

int main()
{
    volatile char key;
    const uint8_t welcome1[] = "********************************************\n\r";
    const uint8_t welcome2[] = "  Interfacing OLED with I2C on SmartFusion  \n\r";
    const uint8_t welcome3[] = "********************************************";
    const uint8_t pattern[]  = "\n\r\n\r1 - Plain Text Display"
			                   "\n\r2 - Vertical Scrolling"
			                   "\n\r3 - Horizontal Scrolling"
    		                   "\n\r4 - continuous Horizontal & Vertical Scrolling"
			                   "\n\r5 - Sine Wave"
    		                   "\n\r6 - Clear the OLED data\n\r"
			                   "\n\rEnter the Option (1/2/3/4/5/6): ";
    char *string1=" SMARTFUSION";
    char *string2=" INNOVATIVE ";
    char *string3=" INTELLIGENT ";
    char *string4=" MIXED SIGNAL";
    char *string5=" FPGA ";

    uint8_t i;

    struct oled_data write_data;

    write_data.line1 = FIRST_LINE;
    write_data.char_offset1 = FIRST_CHARACTER;
    write_data.string1 = string1;

    write_data.line2 = SECOND_LINE;
    write_data.char_offset2 = FIRST_CHARACTER;
    write_data.string2 = string2;

    write_data.line3 = THIRD_LINE;
    write_data.char_offset3 = FIRST_CHARACTER;
    write_data.string3 = string3;

    write_data.line4 = FOURTH_LINE;
    write_data.char_offset4 = FIRST_CHARACTER;
    write_data.string4 = string4;

    write_data.line5 = FIFTH_LINE;
    write_data.char_offset5 = FIRST_CHARACTER;
    write_data.string5 = string5;

    write_data.contrast_val = 0xFF;

    /* Watchdog Disabling function*/
    MSS_WD_disable();

    /* OLED Initialization */
    OLED_init();

    /* UART Initialization and Configuration */
    MSS_UART_init
    (
        &g_mss_uart0,
        MSS_UART_57600_BAUD,
        MSS_UART_DATA_8_BITS | MSS_UART_NO_PARITY | MSS_UART_ONE_STOP_BIT
    );

    MSS_UART_polled_tx( &g_mss_uart0, welcome1, sizeof(welcome1));
    MSS_UART_polled_tx( &g_mss_uart0, welcome2, sizeof(welcome2));
    MSS_UART_polled_tx( &g_mss_uart0, welcome3, sizeof(welcome3));

    /* plain Text display */
    OLED_write_data(&write_data,FIRST_TWO_LINES);

    while(1)
    {
        MSS_UART_polled_tx_string(&g_mss_uart0, pattern);
        key = readchar();
        switch(key)
        {
            case('1'):
                /* plain Text display */
                OLED_write_data(&write_data,FIRST_TWO_LINES);
            break;

            case('2'):
                /* Vertical scrolling */
		        write_data.on_off = 0x0;
                write_data.vertical_on_off = 0x01;
                for(i=0; i<3; i++)
                {
                    write_data.vert_scroll_offset = 0x1F;
                    OLED_vertical_scroll(&write_data);
                    delay(6000000);

                    write_data.vert_scroll_offset = 0x18;
                    OLED_vertical_scroll(&write_data);
                    delay(6000000);

                    write_data.vert_scroll_offset = 0x10;
                    OLED_vertical_scroll(&write_data);
                    delay(6000000);

                    write_data.vert_scroll_offset = 0x08;
                    OLED_vertical_scroll(&write_data);
                    delay(6000000);
                    write_data.vert_scroll_offset = 0x00;
					OLED_vertical_scroll(&write_data);
					delay(6000000);

                }
            break;

            case('3'):
                /* Horizontal scrolling */
                write_data.column_scrool_per_step = 0x08;
                write_data.start_page = 0x01;
                write_data.time_intrval_btw_scroll_step = 0x00;
                write_data.end_page = 0x05;
                write_data.on_off = 0x01;
                OLED_horizontal_scroll(&write_data);
                delay(95000000);
                write_data.on_off = 0x00;
                OLED_horizontal_scroll(&write_data);
                OLED_write_data(&write_data,FIRST_TWO_LINES);
            break;
            case('4'):
                         /*cont horiz &  Vertical scrolling */

		    write_data.contrast_val                 = OLED_CONTRAST_VAL;
			write_data.vertical_on_off				= OLED_VERT_SCROLL_ON;
			write_data.horiz_scroll_direction		= OLED_RIGHT_HORIZ_SCROLL;
			write_data.column_scrool_per_step       = OLED_HORIZ_SCROLL_STEP;
			write_data.start_page                   = OLED_START_PAGE;
			write_data.time_intrval_btw_scroll_step = OLED_HORIZ_SCROLL_TINVL;
			write_data.end_page                     = OLED_END_PAGE;
			write_data.vert_scroll_offset			= 0x01;


			 OLED_write_data(&write_data, FIRST_TWO_LINES);
			    OLED_cont_vert_and_horiz_scroll(&write_data);
			    delay(90000000);
				 write_data.on_off = 0x00;
				 OLED_horizontal_scroll(&write_data);
				 OLED_write_data(&write_data,FIRST_TWO_LINES);
			 break;

            case('5'):
                /* Sine wave generation  */

			   for(i =0; i<75; i++)
			   {
					put_pixel(3.0);
					put_pixel(2.5);
					put_pixel(1.5);
					put_pixel(1.0);
					put_pixel(0.5);
					put_pixel(1.0);
					put_pixel(1.5);
					put_pixel(2.5);
					put_pixel(3.0);
					put_pixel(2.5);
					put_pixel(1.5);
					put_pixel(1.0);
					put_pixel(0.5);
					put_pixel(1.0);
					put_pixel(1.5);
					put_pixel(2.5);
					put_pixel(3.0);
					put_pixel(2.5);
					put_pixel(1.5);
					put_pixel(1.0);
					put_pixel(0.5);
					put_pixel(1.0);
					put_pixel(1.5);
					put_pixel(2.5);
					put_pixel(3.0);
					delay(800000);;
					OLED_clear_display(ALL_LINES);
			 }
            OLED_write_data(&write_data,FIRST_TWO_LINES);
            break;
            case('6'):
            OLED_clear_display(ALL_LINES);
            break;
            default  :
                /* plain Text display */
                OLED_write_data(&write_data,ALL_LINES);
            break;
        }
    }

    return 0;
}

