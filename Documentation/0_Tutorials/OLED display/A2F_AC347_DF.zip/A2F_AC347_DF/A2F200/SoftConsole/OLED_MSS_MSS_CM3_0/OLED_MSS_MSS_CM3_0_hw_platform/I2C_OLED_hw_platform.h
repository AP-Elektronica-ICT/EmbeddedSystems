#ifndef I2C_OLED_HW_PLATFORM_H_
#define I2C_OLED_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Actel SmartDesign  Mon Nov 12 10:33:52 2012
*
*Memory map specification for peripherals in I2C_OLED
*/

/*-----------------------------------------------------------------------------
* MSS_CM3_0 subsystem memory map
* Master(s) for this subsystem: MSS_CM3_0 
*---------------------------------------------------------------------------*/


#endif /* I2C_OLED_HW_PLATFORM_H_*/
